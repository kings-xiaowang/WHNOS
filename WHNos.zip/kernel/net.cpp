/* net.cpp — WHNos 网络协议基础: 以太网 + ARP + IPv4 + ICMP
 *
 * 目标: 让 WHNos 能通过网卡联网。当前实现:
 *   - PCI 枚举 -> RTL8139 驱动 (轮询)
 *   - 静态 IP 配置 (QEMU user 网络: 10.0.2.15/24, 网关 10.0.2.2)
 *   - ARP 解析邻居 MAC
 *   - ICMP echo 收发 (可被 ping, 也可 ping 网关验证连通)
 * 后续扩展: DHCP / UDP / TCP / HTTP, 进而实现 apt 拉包。
 */
#include "net.h"
#include "vga.h"
#include "pit.h"
#include "pci.h"
#include "rtl8139.h"
#include "e1000.h"

namespace Net {

    // 网卡选择: true = Intel e1000 (VMware E1000 / QEMU e1000)
    //           false = RTL8139 (QEMU 老型号 / 实机老网卡)
    static bool gUseE1000 = false;

    uint8_t  myMAC[6] = {0};
    uint32_t myIP  = 0x0F02000A;   // 10.0.2.15  内存中的网络序字节 [0A 00 02 0F]
    uint32_t myMask= 0x00FFFFFF;   // 255.255.255.0
    uint32_t myGW  = 0x0202000A;   // 10.0.2.2   网关
    uint8_t  gwMAC[6] = {0};
    bool     gwKnown = false;

    static uint32_t gRx = 0, gTx = 0, gErr = 0;
    static bool gUp = false;

    // ARP 单条目缓存 (最近解析的邻居)
    static uint32_t gArpIP = 0;
    static uint8_t  gArpMAC[6] = {0};
    static bool     gArpCached = false;

    // ICMP echo 等待
    static uint16_t gEchoId = 0, gEchoSeq = 0;
    static bool gEchoDone = false, gEchoOk = false;

    static uint8_t gTxFrame[NET_MTU];
    static uint8_t gRxFrame[NET_MTU];

    // 前向声明 (init 中在定义前调用)
    static bool arpResolve(uint32_t ip);
    static int  pollOnce();

    // ---- 内部工具 ----

    static uint16_t in16(const uint8_t* p) { return (uint16_t)((p[0] << 8) | p[1]); }
    static void     packs(uint8_t* p, uint16_t v) { p[0] = (uint8_t)(v >> 8); p[1] = (uint8_t)v; }

    static uint16_t checksum(const uint8_t* data, int len) {
        uint32_t sum = 0;
        int i = 0;
        for (; i + 1 < len; i += 2) sum += (uint16_t)((data[i] << 8) | data[i + 1]);
        if (i < len) sum += (uint16_t)(data[i] << 8);
        while (sum >> 16) sum = (sum & 0xFFFF) + (sum >> 16);
        return (uint16_t)~sum;
    }

    static void ethSwappedMAC(const uint8_t* theirMAC) {
        for (int i = 0; i < 6; i++) {
            gTxFrame[i] = theirMAC[i];       // dst
            gTxFrame[6 + i] = myMAC[i];      // src
        }
    }

    // ---- 帧构造 ----

    static void sendARPFrame(bool isReq, const uint8_t* peerMAC, uint32_t peerIP) {
        const uint8_t* dstMAC = isReq ? (const uint8_t*)"\xFF\xFF\xFF\xFF\xFF\xFF" : peerMAC;
        ethSwappedMAC(dstMAC);
        packs(gTxFrame + 12, 0x0806);        // ethertype = ARP
        uint8_t* a = gTxFrame + 14;
        packs(a + 0, 1); a[2] = 0x08; a[3] = 0x00;      // htype=1, ptype=IP
        a[4] = 6; a[5] = 4;                             // hlen, plen
        packs(a + 6, isReq ? 1 : 2);                    // op
        for (int i = 0; i < 6; i++) { a[8 + i] = myMAC[i]; a[18 + i] = isReq ? 0 : peerMAC[i]; }
        for (int i = 0; i < 4; i++) { a[14 + i] = ((const uint8_t*)&myIP)[i]; a[24 + i] = ((const uint8_t*)&peerIP)[i]; }
        sendRaw(gTxFrame, 14 + 28);
    }

    // 发送 ICMP 报文 (通过 dstMAC 指定下一跳)
    static void sendICMP(bool req, uint32_t dstIP, const uint8_t* dstMAC,
                         uint16_t id, uint16_t seq, const uint8_t* payload, int plen) {
        ethSwappedMAC(dstMAC);
        packs(gTxFrame + 12, 0x0800);        // ethertype = IPv4
        uint8_t* ip = gTxFrame + 14;
        ip[0] = 0x45; ip[1] = 0;
        int totalLen = 20 + 8 + plen;
        packs(ip + 2, totalLen);
        packs(ip + 4, (uint16_t)(0x0100 + (gTx & 0x7FFF)));
        packs(ip + 6, 0x0000);
        ip[8] = 64; ip[9] = 1;               // ttl, proto=ICMP
        packs(ip + 10, 0);
        for (int i = 0; i < 4; i++) { ip[12 + i] = ((const uint8_t*)&myIP)[i]; ip[16 + i] = ((const uint8_t*)&dstIP)[i]; }
        packs(ip + 10, checksum(ip, 20));

        uint8_t* ic = ip + 20;
        ic[0] = req ? 8 : 0; ic[1] = 0;
        packs(ic + 2, 0);
        packs(ic + 4, id);
        packs(ic + 6, seq);
        for (int i = 0; i < plen; i++) ic[8 + i] = payload[i];
        packs(ic + 2, checksum(ic, 8 + plen));

        sendRaw(gTxFrame, 14 + totalLen);
    }

    // ---- 对外接口 ----

    void init() {
        VGA::write("Net: scanning PCI... ");

        // 优先尝试 Intel e1000 (VMware E1000 / QEMU e1000)
        if (E1000::init()) {
            gUseE1000 = true;
            VGA::writeLine("found Intel Pro/1000 (e1000)");
        } else {
            VGA::writeLine("no e1000, trying RTL8139...");
            uint16_t bdf = PCI::findDevice(PCI_VENDOR_REALTEK, PCI_DEV_RTL8139);
            if (bdf == 0xFFFF) { VGA::writeLine("no supported NIC found"); return; }
            VGA::write("found RTL8139 (bus0 dev ");
            char b[8];
            b[0] = '0' + ((bdf >> 8) / 10);
            b[1] = '0' + ((bdf >> 8) % 10);
            b[2] = '\0';
            VGA::write(b);
            VGA::writeLine(")");

            if (!RTL8139::init()) { VGA::writeLine("Net: RTL8139 init failed"); return; }
            VGA::write("  IO 0x");
            {
                static const char* hx = "0123456789ABCDEF";
                uint32_t io = RTL8139::ioBase();
                char hb[9];
                for (int i = 7; i >= 0; i--) hb[7 - i] = hx[(io >> (i * 4)) & 0xF];
                hb[8] = '\0';
                VGA::write(hb);
            }
            VGA::writeLine("");
        }

        const uint8_t* m = gUseE1000 ? E1000::mac() : RTL8139::mac();
        for (int i = 0; i < 6; i++) myMAC[i] = m[i];
        gUp = true;

        char s[32];
        VGA::write("Net: MAC ");
        macStr(s); VGA::write(s);
        VGA::write("  IP ");
        ipStr(s); VGA::write(s);
        VGA::write("  GW ");
        gatewayStr(s); VGA::writeLine("");

        VGA::write("Net: resolving gateway... ");
        if (arpResolve(myGW)) {
            VGA::write("ok  gw MAC ");
            char buf[20];
            for (int i = 0; i < 6; i++) {
                static const char* hx = "0123456789ABCDEF";
                buf[i * 3]     = hx[gwMAC[i] >> 4];
                buf[i * 3 + 1] = hx[gwMAC[i] & 0xF];
                buf[i * 3 + 2] = ':';
            }
            buf[17] = '\0';
            VGA::writeLine(buf);
        } else {
            VGA::writeLine("timed out (will retry on demand)");
        }
    }

    bool isUp() { return gUp; }

    const char* nicName() {
        if (!gUp) return "none";
        return gUseE1000 ? "Intel e1000 (MMIO)" : "RTL8139 (IO)";
    }
    uint32_t rxCount() { return gRx; }
    uint32_t txCount() { return gTx; }
    uint32_t errCount() { return gErr; }

    void macStr(char* out) {
        static const char* hx = "0123456789ABCDEF";
        for (int i = 0; i < 6; i++) {
            out[i * 3]     = hx[myMAC[i] >> 4];
            out[i * 3 + 1] = hx[myMAC[i] & 0xF];
            out[i * 3 + 2] = ':';
        }
        out[17] = '\0';
    }

    void ipToStr(uint32_t ip, char* out) {
        const uint8_t* p = (const uint8_t*)&ip;
        auto wr = [&](int v) {
            if (v >= 100) *out++ = (char)('0' + v / 100);
            if (v >= 10)  *out++ = (char)('0' + (v / 10) % 10);
            *out++ = (char)('0' + v % 10);
        };
        wr(p[0]); *out++ = '.';
        wr(p[1]); *out++ = '.';
        wr(p[2]); *out++ = '.';
        wr(p[3]); *out = '\0';
    }

    void ipStr(char* out) { ipToStr(myIP, out); }
    void maskStr(char* out) { ipToStr(myMask, out); }
    void gatewayStr(char* out) { ipToStr(myGW, out); }

    uint32_t parseIP(const char* s) {
        uint8_t o[4] = {0, 0, 0, 0};
        int n = 0, v = 0;
        if (!s) return 0xFFFFFFFF;
        for (const char* p = s;; p++) {
            if (*p >= '0' && *p <= '9') v = v * 10 + (*p - '0');
            else if (*p == '.') {
                if (n > 3 || v > 255) return 0xFFFFFFFF;
                o[n++] = (uint8_t)v; v = 0;
            }
            else if (*p == '\0') {
                if (n != 3 || v > 255) return 0xFFFFFFFF;
                o[3] = (uint8_t)v;
                uint32_t ip = 0;
                for (int i = 0; i < 4; i++) ((uint8_t*)&ip)[i] = o[i];
                return ip;
            }
            else return 0xFFFFFFFF;
        }
    }

    void sendRaw(const uint8_t* frame, int len) {
        if (!gUp) return;
        if (gUseE1000) E1000::sendFrame(frame, len);
        else           RTL8139::sendFrame(frame, len);
        gTx++;
    }

    // ---- ARP 解析 (带阻塞轮询) ----

    static bool arpResolve(uint32_t ip) {
        if (ip == myGW && gwKnown) return true;
        if (gArpCached && gArpIP == ip) return true;

        sendARPFrame(true, 0, ip);
        uint32_t start = PIT::ticks();
        while (PIT::ticks() - start < 800) {
            pollOnce();
            if (ip == myGW && gwKnown) return true;
            if (gArpCached && gArpIP == ip) return true;
        }
        return (ip == myGW) ? gwKnown : (gArpCached && gArpIP == ip);
    }

    // ---- 收包 ----

    static int pollOnce() {
        int n;
        if (gUseE1000) n = E1000::pollFrame(gRxFrame, NET_MTU);
        else           n = RTL8139::pollFrame(gRxFrame, NET_MTU);
        if (n <= 0) return 0;
        onRx(gRxFrame, n);
        return 1;
    }

    void poll() {
        for (int i = 0; i < 8; i++) {
            if (pollOnce() == 0) break;
        }
    }

    void onRx(const uint8_t* frame, int len) {
        if (len < ETH_HDR_LEN + 4) return;
        gRx++;
        uint16_t type = in16(frame + 12);
        if (type == 0x0806)       { handleArp(frame + 14); }
        else if (type == 0x0800)  { handleIPv4(frame + 14, frame + 6); }
    }

    void handleArp(const uint8_t* a) {
        uint16_t op = in16(a + 6);
        uint32_t spa = 0, tpa = 0;
        for (int i = 0; i < 4; i++) {
            ((uint8_t*)&spa)[i] = a[14 + i];
            ((uint8_t*)&tpa)[i] = a[24 + i];
        }
        if (!gwKnown && spa == myGW) {
            for (int i = 0; i < 6; i++) gwMAC[i] = a[8 + i];
            gwKnown = true;
        }
        if (op == 1 && tpa == myIP) {          // ARP request -> 应答
            uint8_t mac[6];
            for (int i = 0; i < 6; i++) mac[i] = a[8 + i];
            sendARPFrame(false, mac, spa);
        } else if (op == 2) {                  // ARP reply -> 学习
            gArpIP = spa;
            for (int i = 0; i < 6; i++) gArpMAC[i] = a[8 + i];
            gArpCached = true;
        }
    }

    void handleIPv4(const uint8_t* ip, const uint8_t* srcMAC) {
        if ((ip[0] >> 4) != 4) return;
        int ihl = (ip[0] & 0xF) * 4;
        uint32_t dst = 0;
        for (int i = 0; i < 4; i++) ((uint8_t*)&dst)[i] = ip[16 + i];
        if (dst != myIP && dst != 0xFFFFFFFF) return;   // 仅本机/广播
        if (ip[9] != 1) return;                         // 仅 ICMP

        const uint8_t* ic = ip + ihl;
        if (ic[0] == 8) {                     // echo request -> 回显应答
            uint16_t id = in16(ic + 4), seq = in16(ic + 6);
            int plen = (int)in16(ip + 2) - ihl - 8;
            if (plen < 0) plen = 0;
            // 应答目标 MAC: 优先用 ARP 缓存中的来源 (QEMU 中通常即网关)
            const uint8_t* dmac = gwMAC;
            if (gArpCached && gArpIP == dst) dmac = gArpMAC;
            else if (srcMAC) dmac = srcMAC;
            sendICMP(false, dst, dmac, id, seq, ic + 8, plen);
        } else if (ic[0] == 0) {              // echo reply
            uint16_t id = in16(ic + 4), seq = in16(ic + 6);
            VGA::writeLine("icmp reply rx");
            if (id == gEchoId && seq == gEchoSeq) { gEchoDone = true; gEchoOk = true; }
        }
    }

    // ---- ping ----

    bool pingOnce(uint32_t ip, int seq) {
        if (!gUp) return false;

        // 同子网直连, 否则走网关
        uint32_t nextHop;
        if ((ip & myMask) == (myIP & myMask)) nextHop = ip;
        else nextHop = myGW;

        // 解析下一跳 MAC
        const uint8_t* dmac = 0;
        if (nextHop == myGW) {
            if (!gwKnown && !arpResolve(myGW)) return false;
            dmac = gwMAC;
        } else {
            if (!gArpCached || gArpIP != ip) {
                if (!arpResolve(ip)) return false;
            }
            dmac = gArpMAC;
        }

        uint8_t payload[32];
        for (int i = 0; i < 32; i++) payload[i] = (uint8_t)i;
        gEchoId = (uint16_t)(gTx & 0xFFFF);
        gEchoSeq = (uint16_t)seq;
        gEchoDone = false; gEchoOk = false;

        sendICMP(true, ip, dmac, gEchoId, gEchoSeq, payload, 32);

        uint32_t start = PIT::ticks();
        while (PIT::ticks() - start < 3000) {
            pollOnce();
            if (gEchoDone) break;
        }
        return gEchoOk;
    }
}
